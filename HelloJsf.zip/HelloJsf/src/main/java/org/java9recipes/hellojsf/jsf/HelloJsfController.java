/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.java9recipes.hellojsf.jsf;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import org.java9recipes.hellojsf.entity.HelloUser;
import org.java9recipes.hellojsf.model.User;
import org.java9recipes.hellojsf.session.HelloUserFacade;

/**
 *
 * @author Juneau
 */
@Named
@ViewScoped
public class HelloJsfController implements java.io.Serializable {
    
    @EJB
    private HelloUserFacade helloUserFacade;

    private User user;
    private HelloUser helloUser;
    private List<HelloUser> helloUserList;
    private String freeText;
    
    @PostConstruct
    public void init() {
        helloUserList = helloUserFacade.findAll();
    }

    /**
     * @return the user
     */
    public User getUser() {
        if(user == null){
            user = new User();
        }
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    public void createUser(){
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage("Successfully Added User: " +
                            user.getFirstName() + " " + user.getLastName()));
        user = null;
    }
    
    /**
     * Creates a HelloUser, persisting to the underlying data store.
     */
    public void createAndPersistUser(){
        FacesContext context = FacesContext.getCurrentInstance();
        helloUserFacade.create(helloUser);
        context.addMessage(null, new FacesMessage("Successfully Persisted User: " +
                            user.getFirstName() + " " + user.getLastName()));
        helloUserList = null;
    }

    /**
     * @return the helloUser
     */
    public HelloUser getHelloUser() {
        if(helloUser == null){
            helloUser = new HelloUser();
        }
        return helloUser;
    }

    /**
     * @param helloUser the helloUser to set
     */
    public void setHelloUser(HelloUser helloUser) {
        this.helloUser = helloUser;
    }
    
    /**
     * @return the helloUserList
     */
    public List<HelloUser> getHelloUserList() {
        if(helloUserList == null){
            helloUserList = helloUserFacade.findAll();
        }
        return helloUserList;
    }

    /**
     * @param helloUserList the helloUserList to set
     */
    public void setHelloUserList(List<HelloUser> helloUserList) {
        this.helloUserList = helloUserList;
    }

    /**
     * @return the freeText
     */
    public String getFreeText() {
        return freeText;
    }

    /**
     * @param freeText the freeText to set
     */
    public void setFreeText(String freeText) {
        this.freeText = freeText;
    }
    
    /**
     * Action method that assigns the current value of freeText to a FacesMessage
     * @param evt 
     */
    public void displayText(AjaxBehaviorEvent evt){
        FacesContext context = FacesContext.getCurrentInstance();
        System.out.println("test: " + freeText);
        context.addMessage(null, new FacesMessage(freeText));
    }
    
}
