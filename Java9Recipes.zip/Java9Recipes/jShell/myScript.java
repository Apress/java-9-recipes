System.out.println("Hello from the jShell Script!")
/x