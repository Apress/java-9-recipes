
package org.java9recipes.chapter05.recipe5_04;

/**
 * Recipe 5-4
 * @author juneau
 */
public interface PlayerType {
    public String position = null;
    
    
    public String getPosition();
}
