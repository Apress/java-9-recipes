module org.firstModule {
    requires org.secondModule;
}
