package org.java9recipes.chapter11.recipe11_02;

import java.util.Random;

/**
 * User: Freddy
 * Date: 9/16/11
 * Time: 5:33 PM
 * Math Adder Class
 */
public class Recipe_11_2_MathAdder {

    public int addNumbers (int first, int second) {
        return first+second;

    }

    public int substractNumber (int first, int second) {
        return first-second;
    }

}
