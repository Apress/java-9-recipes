/* 
 * Database creation script for the HelloJsf application.
 */
/**
 * Author:  Juneau
 * Created: Apr 3, 2017
 */
create table hello_user (
id numeric primary key,
first_name      varchar(50),
last_name       varchar(50),
email           varchar(150));

