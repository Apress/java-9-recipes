module org.secondModule {
    exports org.secondModule;
}
