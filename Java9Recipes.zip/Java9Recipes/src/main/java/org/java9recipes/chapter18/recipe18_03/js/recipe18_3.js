#! /usr/bin/env
function gallons(width, length, avgDepth){var volume = avgDepth * width * length;
                                         return volume * 7.48; }                                 
print("Gallons of water in pool: ${gallons(16,32,5)}");                                    