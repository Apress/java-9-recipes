

package org.java9recipes.chapter02.recipe2_07;

import java.time.LocalDate;
import java.time.LocalTime;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Recipe 2-7:  Platform Logging API
 * @author Juneau
 */
public class Recipe02_07 {
    
    private static Logger log = LogManager.getLogger();
    public static void main(String[] args){
        
        LocalDate myDate = LocalDate.now();
        LocalTime myTime = LocalTime.now();

        LocalDate datePlusDays = myDate.plusDays(15);
        System.out.println("Today Plus 15 Days: " + datePlusDays);
        LocalDate datePlusWeeks = myDate.plusWeeks(8);
        System.out.println("Today Plus 8 weeks: " + datePlusWeeks);

        LocalTime timePlusHours = myTime.plusHours(5);
        LocalTime timeMinusMin = myTime.minusMinutes(30);

        log.debug("Time Plus 5 Hours: " + timePlusHours);
        log.debug("Time Minus 30 Minutes: " + timeMinusMin);
        
    }
}
