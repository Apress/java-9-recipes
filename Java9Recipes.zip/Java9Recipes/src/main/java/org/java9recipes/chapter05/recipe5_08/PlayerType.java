
package org.java9recipes.chapter05.recipe5_08;

/**
 * Recipe 5-8
 * @author juneau
 */
public interface PlayerType {
    public String position = null;
    
    
    public String getPosition();
}
