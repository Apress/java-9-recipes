/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.java9recipes.chapter02.recipe2_02;

/**
 *
 * @author Juneau
 */
public class Recipe02_02 {
    
}
