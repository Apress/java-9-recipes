var parameter = arguments[0];
print(parameter ? "Hello "+ parameter + "!": "Hello Nashorn!");
print(parameter ? "Hello ${parameter}!":"Hello Nashorn!");

