

package org.java9recipes.chapter05.recipe5_07;

/**
 * Recipe 5-7
 * 
 * @author Juneau
 */
public class HockeyPlayer extends Player {
    public HockeyPlayer(){
        // Used for testing only
    }
}
