

package org.java9recipes.chapter15.recipe15_06;

/**
 *
 * @author Juneau
 */
public class JavaFX3dExamples {
    
}
