/* 
 * Simple "Hello World" example
 */
print("Hello Nashorn!");

