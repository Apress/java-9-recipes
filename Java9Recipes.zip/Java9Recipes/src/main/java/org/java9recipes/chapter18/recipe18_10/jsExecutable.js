#! /usr/bin/env jjs
print('I am an executable');
var threeyr = 365 * 3;
print("The number of days in three years is ${threeyr}");

